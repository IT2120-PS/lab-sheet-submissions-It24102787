setwd("C:\\Users\\ADMIN\\OneDrive\\Desktop\\it24102787")
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)
pexp(2, rate = 1/3, lower.tail = TRUE)
1 - pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)
qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)

